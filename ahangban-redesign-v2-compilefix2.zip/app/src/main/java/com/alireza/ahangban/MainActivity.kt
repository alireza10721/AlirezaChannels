package com.alireza.ahangban

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

data class Tone(val titleFa:String, val titleEn:String, val file:String, val sms:Boolean, val source:String="AhangBan")

class MainActivity : Activity() {
    private var player: MediaPlayer? = null
    private var dark=false
    private var smsMode=false
    private var page=0
    private var busy=false
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private lateinit var refresh: Button
    private val smsTones= mutableListOf<Tone>()
    private val ringTones= mutableListOf<Tone>()
    private val pageSize=10
    private val purple=Color.rgb(111,72,190)

    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        (1..8).forEach { smsTones.add(Tone("پیامک کوتاه $it","Short alert $it","sms%02d.wav".format(it),true)) }
        (1..6).forEach { ringTones.add(Tone("ملودی زنگ $it","Melody ringtone $it","ringtone%02d.wav".format(it),false)) }
        showHome()
    }
    private fun en():Boolean {
        val l=if(Build.VERSION.SDK_INT>=24) resources.configuration.locales[0].language else resources.configuration.locale.language
        return l=="en"
    }
    private fun t(f:String,e:String)=if(en()) e else f
    private fun bg(color:Int,r:Float=20f)=GradientDrawable().apply{setColor(color);cornerRadius=r}
    private fun fg()=if(dark) Color.WHITE else Color.rgb(35,27,48)
    private fun muted()=if(dark) Color.rgb(190,180,207) else Color.rgb(112,101,128)
    private fun surface()=if(dark) Color.rgb(43,34,58) else Color.WHITE
    private fun label(value:String,size:Float,color:Int=fg(),bold:Boolean=false)=TextView(this).apply{
        text=value;textSize=size;setTextColor(color);if(bold)setTypeface(null,Typeface.BOLD)
    }

    private fun showHome() {
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,18,18,12);setBackgroundColor(if(dark)Color.rgb(22,17,32) else Color.rgb(247,244,252))}
        val header=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,20,20,20);background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(93,57,163),Color.rgb(151,92,209))).apply{cornerRadius=32f}}
        header.addView(label("♫  "+t("آهنگ‌بان","AhangBan"),27f,Color.WHITE,true))
        header.addView(label(t("آهنگ دلخواهت را انتخاب کن","Choose a sound that fits you"),13f,Color.rgb(239,228,255)))
        root.addView(header)
        val tabs=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(0,16,0,8)}
        tabs.addView(actionButton(t("🎵 آهنگ زنگ","🎵 Ringtones"),!smsMode){smsMode=false;page=0;renderList()},LinearLayout.LayoutParams(0,52,1f))
        tabs.addView(actionButton(t("🔔 پیامک کوتاه","🔔 SMS alerts"),smsMode){smsMode=true;page=0;renderList()},LinearLayout.LayoutParams(0,52,1f))
        root.addView(tabs)
        val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        bar.addView(label(t("کتابخانه صداها","Sound library"),18f,fg(),true),LinearLayout.LayoutParams(0,-2,1f))
        refresh=actionButton(t("↻ بروزرسانی","↻ Refresh"),false){refreshOnline()}
        bar.addView(refresh);root.addView(bar)
        status=label(t("آهنگ‌های زنگ ملودی کامل‌اند؛ صداهای پیامک کوتاه و جداگانه‌اند.","Ringtones are full melodies; SMS alerts are short and separate."),12f,muted())
        status.setPadding(2,10,2,12);root.addView(status)
        list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val scroll=ScrollView(this);scroll.addView(list);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        root.addView(actionButton(t("⚙ تنظیمات","⚙ Settings"),false){showSettings()})
        setContentView(root);renderList()
    }

    private fun actionButton(labelText:String,selected:Boolean,lp:LinearLayout.LayoutParams?=null,action:()->Unit):Button {
        val b=Button(this).apply{text=labelText;textSize=12f;isAllCaps=false;setTextColor(if(selected)Color.WHITE else fg());background=bg(if(selected)purple else surface(),18f);setPadding(10,0,10,0);setOnClickListener{action()}}
        if(lp!=null)b.layoutParams=lp
        return b
    }
    private fun current():MutableList<Tone> = if(smsMode)smsTones else ringTones

    private fun renderList() {
        if(!::list.isInitialized)return
        list.removeAllViews()
        val items=current();val total=maxOf(1,(items.size+pageSize-1)/pageSize)
        if(page>=total)page=total-1
        items.drop(page*pageSize).take(pageSize).forEach { tone ->
            val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(14,12,14,12);background=bg(surface(),22f)}
            val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            val icon=TextView(this).apply{text=if(tone.sms)"🔔" else "🎼";textSize=23f;gravity=Gravity.CENTER;background=bg(if(dark)Color.rgb(62,48,82) else Color.rgb(242,235,252),18f)}
            top.addView(icon,LinearLayout.LayoutParams(54,54))
            val info=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(12,0,4,0)}
            info.addView(label(if(en())tone.titleEn else tone.titleFa,15f,fg(),true))
            info.addView(label(tone.source,11f,muted()))
            top.addView(info,LinearLayout.LayoutParams(0,-2,1f));card.addView(top)
            val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(0,8,0,0)}
            buttons.addView(actionButton(t("▶ پخش","▶ Play"),false){play(tone)},LinearLayout.LayoutParams(0,44,1f))
            buttons.addView(actionButton(t("اعمال","Apply"),true){applyTone(tone)},LinearLayout.LayoutParams(0,44,1f))
            card.addView(buttons);val lp=LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=10;list.addView(card,lp)
        }
        val pager=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER}
        pager.addView(actionButton(t("قبلی","Previous"),false){if(page>0){page--;renderList()}})
        pager.addView(label("   ${page+1} / $total   ",14f,fg(),true).apply{gravity=Gravity.CENTER})
        pager.addView(actionButton(t("بعدی","Next"),false){if(page+1<total){page++;renderList()}})
        list.addView(pager)
    }

    private fun play(tone:Tone) {
        try {
            player?.release()
            val f=File(filesDir,tone.file)
            if(f.exists()) player=MediaPlayer().apply{setDataSource(f.absolutePath);setOnCompletionListener{it.release();player=null};prepare();start()}
            else {
                val afd=assets.openFd("tones/${tone.file}")
                player=MediaPlayer().apply{setDataSource(afd.fileDescriptor,afd.startOffset,afd.length);setOnCompletionListener{it.release();player=null};prepare();start()}
                afd.close()
            }
        }catch(_:Exception){setStatus(t("پخش این صدا ممکن نشد.","Could not play this sound."))}
    }

    private fun applyTone(tone:Tone) {
        if(Build.VERSION.SDK_INT>=23 && !Settings.System.canWrite(this)) {
            setStatus(t("برای اعمال صدا، اجازه تغییر تنظیمات سیستم را فعال کن.","Allow modify system settings to apply the sound."))
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,Uri.parse("package:$packageName")));return
        }
        try {
            val src=File(filesDir,tone.file)
            if(!src.exists())assets.open("tones/${tone.file}").use{input->FileOutputStream(src).use{input.copyTo(it)}}
            val values=ContentValues().apply{
                put(MediaStore.MediaColumns.DISPLAY_NAME,"AhangBan_${tone.file}");put(MediaStore.MediaColumns.MIME_TYPE, if (tone.file.lowercase().endsWith(".mp3")) "audio/mpeg" else "audio/wav")
                put(MediaStore.Audio.Media.IS_RINGTONE,!tone.sms);put(MediaStore.Audio.Media.IS_NOTIFICATION,tone.sms)
                put(MediaStore.Audio.Media.IS_ALARM,false);put(MediaStore.Audio.Media.IS_MUSIC,false)
            }
            val uri=contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,values)?:error("MediaStore insert failed")
            contentResolver.openOutputStream(uri)?.use{out->src.inputStream().use{it.copyTo(out)}}
            RingtoneManager.setActualDefaultRingtoneUri(this,if(tone.sms)RingtoneManager.TYPE_NOTIFICATION else RingtoneManager.TYPE_RINGTONE,uri)
            setStatus(if(tone.sms)t("صدای اعلان پیش‌فرض تنظیم شد؛ ممکن است پیام‌رسان صدای کانال جداگانه داشته باشد.","Default notification sound set; your messaging app may have a separate channel sound.") else t("ملودی زنگ گوشی تنظیم شد.","Ringtone melody applied."))
        }catch(e:Exception){setStatus(t("اعمال صدا ناموفق بود: ","Apply failed: ")+(e.message?: ""))}
    }

    private fun refreshOnline() {
        if(busy)return
        busy=true;refresh.isEnabled=false;refresh.text=t("در حال دریافت…","Loading…")
        setStatus(t("در حال جست‌وجوی موسیقی دارای مجوز در Internet Archive…","Searching licensed music on Internet Archive…"))
        thread {
            var added=0
            try {
                val q="mediatype:audio AND licenseurl:http*creativecommons.org*"
                val search="https://archive.org/advancedsearch.php?q="+URLEncoder.encode(q,"UTF-8")+"&fl[]=identifier&fl[]=title&fl[]=licenseurl&rows=40&page=1&output=json"
                val docs=JSONObject(getText(search)).getJSONObject("response").getJSONArray("docs")
                for(i in 0 until docs.length()) {
                    val doc=docs.getJSONObject(i);val id=doc.optString("identifier");val title=doc.optString("title",id)
                    val lic=doc.optString("licenseurl","")
                    if(id.isBlank() || !(lic.contains("/licenses/by/")||lic.contains("/licenses/by-sa/")||lic.contains("/publicdomain/zero/")))continue
                    try {
                        val meta=JSONObject(getText("https://archive.org/metadata/"+id))
                        val files=meta.optJSONArray("files")?:continue
                        var mp3:String?=null
                        for(j in 0 until files.length()){
                            val f=files.getJSONObject(j);val name=f.optString("name");val size=f.optString("size").toLongOrNull()?:Long.MAX_VALUE
                            if(name.lowercase().endsWith(".mp3")&&size<15_000_000){mp3=name;break}
                        }
                        val name=mp3?:continue
                        val safe="ia_${id}_${name.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"),"_")}"
                        val dest=File(filesDir,safe)
                        if(!dest.exists())download("https://archive.org/download/$id/"+URLEncoder.encode(name,"UTF-8").replace("+","%20"),dest)
                        if(dest.exists()&&dest.length()>1000){
                            val tone=Tone(title,title,safe,smsMode,"Internet Archive · CC")
                            if(smsMode){
                                val runtime=meta.optJSONObject("metadata")?.optString("runtime","")?.toDoubleOrNull()
                                if(runtime!=null&&runtime<=2.0){runOnUiThread{smsTones.add(tone);added++}}else dest.delete()
                            }else{runOnUiThread{ringTones.add(tone);added++}}
                        }
                    }catch(_:Exception){}
                    if(added>=10)break
                }
            }catch(_:Exception){}
            runOnUiThread{
                busy=false;refresh.isEnabled=true;refresh.text=t("↻ بروزرسانی","↻ Refresh");page=0;renderList()
                setStatus(if(added>0)t("$added آهنگ مجاز جدید اضافه شد.","Added $added new licensed tracks.") else t("آهنگ تازه‌ای پیدا نشد یا اتصال برقرار نشد؛ بعداً دوباره تلاش کن.","No matching new tracks or connection unavailable. Try again later."))
            }
        }
    }
    private fun getText(url:String):String{
        val c=URL(url).openConnection() as HttpURLConnection;c.connectTimeout=12000;c.readTimeout=20000;c.setRequestProperty("User-Agent","AhangBan Android")
        try{return c.inputStream.bufferedReader().use{it.readText()}}finally{c.disconnect()}
    }
    private fun download(url:String,dest:File){
        val c=URL(url).openConnection() as HttpURLConnection;c.connectTimeout=15000;c.readTimeout=45000
        try{c.inputStream.use{input->FileOutputStream(dest).use{input.copyTo(it)}}}finally{c.disconnect()}
    }
    private fun setStatus(s:String){if(::status.isInitialized)status.text=s}

    private fun showSettings(){
        val v=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(22,24,22,22);setBackgroundColor(if(dark)Color.rgb(22,17,32)else Color.rgb(247,244,252))}
        v.addView(label(t("تنظیمات","Settings"),26f,fg(),true))
        v.addView(label(t("ظاهر برنامه","Appearance"),15f,muted(),true).apply{setPadding(0,18,0,8)})
        v.addView(actionButton(t("☾ تغییر حالت شب / روز","☾ Toggle dark / light"), false, action = { dark = !dark; showHome() }))
        v.addView(label(t("زبان برنامه از زبان گوشی پیروی می‌کند.","App language follows your device language."),13f,muted()).apply{setPadding(0,14,0,14)})
        v.addView(label("AhangBan\n"+t("سازنده: alireza10721@gmail.com","Developer: alireza10721@gmail.com"),14f,fg(),true).apply{setPadding(0,20,0,20)})
        v.addView(actionButton(t("بازگشت","Back"), true, action = { showHome() }));setContentView(v)
    }
    override fun onDestroy(){player?.release();player=null;super.onDestroy()}
}
