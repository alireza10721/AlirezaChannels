package com.alireza10721.channels

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("local_settings", Context.MODE_PRIVATE) }
    private lateinit var page: LinearLayout
    private val creator = "alireza10721@gmail.com"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLogin()
    }

    private fun setup(title: String) {
        page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
            setPadding(24, 32, 24, 24)
        }
        page.addView(TextView(this).apply {
            text = title
            textSize = 25f
            setPadding(0, 0, 0, 20)
        })
        setContentView(ScrollView(this).apply { addView(page) })
    }

    private fun note(message: String, size: Float = 16f) {
        page.addView(TextView(this).apply {
            text = message
            textSize = size
            setPadding(0, 8, 0, 12)
        })
    }

    private fun button(label: String, action: () -> Unit) {
        page.addView(Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        })
    }

    private fun field(hintText: String, numeric: Boolean = false): EditText =
        EditText(this).apply {
            hint = hintText
            if (numeric) inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }

    private fun showLogin() {
        setup("Alireza Channels")
        val existing = prefs.getString("pin", null)
        note(if (existing == null) "برای شروع یک رمز عددی حداقل ۴ رقمی بسازید." else "رمز ورود را وارد کنید.")
        val pin = field("رمز عددی", true)
        page.addView(pin)
        button(if (existing == null) "ثبت رمز و ورود" else "ورود") {
            val value = pin.text.toString()
            when {
                value.length < 4 -> toast("رمز باید حداقل ۴ رقم باشد.")
                existing == null -> {
                    prefs.edit().putString("pin", value).apply()
                    showHome()
                }
                value == existing -> showHome()
                else -> toast("رمز اشتباه است.")
            }
        }
        note("سازنده: $creator", 13f)
    }

    private fun showHome() {
        setup("کانال‌های آنلاین")
        note("نسخه اولیه برنامه؛ لینک‌های HTTPS مجاز را اضافه کنید.")
        button("افزودن لینک کانال") {
            val input = field("https://example.com")
            AlertDialog.Builder(this).setTitle("لینک کانال").setView(input)
                .setNegativeButton("انصراف", null)
                .setPositiveButton("ذخیره") { _, _ ->
                    val url = input.text.toString().trim()
                    if (url.startsWith("https://")) {
                        val links = prefs.getStringSet("channels", emptySet())!!.toMutableSet()
                        links.add(url)
                        prefs.edit().putStringSet("channels", links).apply()
                        showHome()
                    } else toast("فقط لینک HTTPS پذیرفته می‌شود.")
                }.show()
        }
        button("وضعیت سرور") {
            AlertDialog.Builder(this)
                .setTitle("سرور تنظیم نشده")
                .setMessage("برای اتصال VPN واقعی باید سرور معتبر و فایل یا لینک پیکربندی WireGuard یا پروتکل سازگار تهیه شود. این نسخه هنوز موتور VPN ندارد.")
                .setPositiveButton("متوجه شدم", null).show()
        }
        val links = prefs.getStringSet("channels", emptySet()) ?: emptySet()
        if (links.isEmpty()) note("هنوز لینکی اضافه نشده است.")
        links.forEachIndexed { i, link ->
            button("باز کردن لینک ${i + 1}") {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link))) }
                catch (_: Exception) { toast("باز کردن لینک ممکن نشد.") }
            }
        }
        button("تغییر رمز") {
            val input = field("رمز جدید (حداقل ۴ رقم)", true)
            AlertDialog.Builder(this).setTitle("تغییر رمز").setView(input)
                .setNegativeButton("انصراف", null)
                .setPositiveButton("ذخیره") { _, _ ->
                    val p = input.text.toString()
                    if (p.length >= 4) {
                        prefs.edit().putString("pin", p).apply()
                        toast("رمز تغییر کرد.")
                    } else toast("رمز باید حداقل ۴ رقم باشد.")
                }.show()
        }
        note("سازنده: $creator", 13f)
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
