package com.alireza10721.channels

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

data class Channel(val name: String, val category: String, val url: String, val logo: String)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("adult_tv_prefs", Context.MODE_PRIVATE) }
    private val io = Executors.newSingleThreadExecutor()
    private lateinit var page: LinearLayout
    private lateinit var status: TextView
    private lateinit var listBox: LinearLayout
    private var channels: List<Channel> = emptyList()
    private var selectedCategory = "همه"

    private val bg = Color.rgb(17, 18, 29)
    private val panel = Color.rgb(31, 33, 49)
    private val accent = Color.rgb(151, 105, 255)
    private val white = Color.WHITE
    private val creator = "alireza10721@gmail.com"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pin = prefs.getString("pin", null)
        if (pin == null) showPin(true) else showPin(false)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shell(title: String) {
        page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(24), dp(18), dp(20))
            setBackgroundColor(bg)
        }
        val scroller = ScrollView(this).apply {
            setBackgroundColor(bg)
            addView(page)
        }
        setContentView(scroller)
        val heading = TextView(this).apply {
            text = title
            textSize = 25f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(14))
        }
        page.addView(heading)
    }

    private fun label(text: String, size: Float = 14f, color: Int = white) {
        page.addView(TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            setPadding(0, dp(6), 0, dp(8))
        })
    }

    private fun button(text: String, action: () -> Unit) {
        val b = Button(this).apply {
            this.text = text
            isAllCaps = false
            setTextColor(white)
            background = rounded(accent, 14)
            setPadding(dp(10), dp(4), dp(10), dp(4))
            setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(-1, dp(48))
        lp.bottomMargin = dp(9)
        page.addView(b, lp)
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun showPin(first: Boolean) {
        shell("ALIREZA  •  ADULT TV")
        label(if (first) "برای شروع یک رمز عددی حداقل ۴ رقمی بسازید." else "رمز ورود را وارد کنید.")
        val input = EditText(this).apply {
            hint = "رمز عددی"
            inputType = 2 or 16
            setTextColor(white); setHintTextColor(Color.LTGRAY)
            background = rounded(panel, 12)
            setPadding(dp(12), 0, dp(12), 0)
        }
        page.addView(input, LinearLayout.LayoutParams(-1, dp(52)))
        button(if (first) "ثبت رمز و ورود" else "ورود") {
            val value = input.text.toString()
            val old = prefs.getString("pin", null)
            when {
                value.length < 4 -> toast("رمز باید حداقل ۴ رقم باشد.")
                first -> { prefs.edit().putString("pin", value).apply(); showHome() }
                value == old -> showHome()
                else -> toast("رمز اشتباه است.")
            }
        }
        label("سازنده: $creator", 12f, Color.LTGRAY)
    }

    private fun showHome() {
        shell("ALIREZA  •  ADULT TV")
        label("فهرست کانال‌ها", 18f)
        status = TextView(this).apply {
            text = "برای دریافت آخرین فهرست، بروزرسانی سرور را بزنید."
            setTextColor(Color.LTGRAY); textSize = 12f
            setPadding(0, 0, 0, dp(12))
        }
        page.addView(status)
        button("⟳  بروزرسانی سرور") { refreshChannels() }
        button("＋  افزودن لینک کانال") { addChannelDialog() }
        button("⚙  تنظیم منبع فهرست") { sourceDialog() }

        val cats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("همه", "عمومی", "زنده", "سایر").forEach { c ->
            val chip = TextView(this).apply {
                text = "  $c  "
                textSize = 13f
                setTextColor(white)
                setPadding(dp(8), dp(9), dp(8), dp(9))
                background = rounded(if (selectedCategory == c) accent else panel, 20)
                setOnClickListener { selectedCategory = c; showHome() }
            }
            val lp = LinearLayout.LayoutParams(-2, -2); lp.marginEnd = dp(6)
            cats.addView(chip, lp)
        }
        page.addView(cats)
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(listBox)
        renderChannels()
        label("سازنده: $creator", 12f, Color.LTGRAY)
        if (channels.isEmpty()) refreshChannels()
    }

    private fun renderChannels() {
        if (!::listBox.isInitialized) return
        listBox.removeAllViews()
        val shown = channels.filter { selectedCategory == "همه" || it.category == selectedCategory }
        if (shown.isEmpty()) {
            val empty = TextView(this).apply {
                text = "هنوز کانالی در فهرست نیست. منبع فهرست را تنظیم یا لینک اضافه کنید."
                textSize = 14f; setTextColor(Color.LTGRAY); setPadding(0, dp(24), 0, dp(24))
            }
            listBox.addView(empty)
        }
        shown.forEach { ch ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = rounded(panel, 16)
                setPadding(dp(12), dp(10), dp(12), dp(10))
            }
            val logo = TextView(this).apply {
                text = ch.logo.ifBlank { ch.name.take(2).uppercase() }
                textSize = 17f; typeface = Typeface.DEFAULT_BOLD; setTextColor(white)
                gravity = Gravity.CENTER
                background = rounded(accent, 50)
            }
            row.addView(logo, LinearLayout.LayoutParams(dp(48), dp(48)))
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12),0,0,0) }
            info.addView(TextView(this).apply { text = ch.name; textSize = 16f; setTextColor(white) })
            info.addView(TextView(this).apply { text = ch.category; textSize = 11f; setTextColor(Color.LTGRAY) })
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            val open = TextView(this).apply {
                text = "▶"; textSize = 20f; setTextColor(white)
                setPadding(dp(12), dp(10), dp(8), dp(10))
                setOnClickListener { openChannel(ch.url) }
            }
            row.addView(open)
            val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(9)
            listBox.addView(row, lp)
        }
    }

    private fun refreshChannels() {
        val source = prefs.getString("feed_url", "")?.trim().orEmpty()
        status.text = "در حال بروزرسانی فهرست…"
        if (source.isBlank()) {
            status.text = "منبع آنلاین تنظیم نشده؛ فهرست آزمایشی نمایش داده می‌شود. برای شبکه‌های واقعی، نشانی JSON معتبر خودتان را وارد کنید."
            channels = demoChannels()
            renderChannels()
            return
        }
        io.execute {
            try {
                val conn = URL(source).openConnection() as HttpURLConnection
                conn.connectTimeout = 10000
                conn.readTimeout = 10000
                conn.requestMethod = "GET"
                conn.setRequestProperty("Accept", "application/json")
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val arr = JSONArray(body)
                val result = mutableListOf<Channel>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val url = o.optString("url")
                    if (url.startsWith("https://")) {
                        result.add(Channel(
                            o.optString("name", "Channel"),
                            o.optString("category", "عمومی"),
                            url,
                            o.optString("logo", "")
                        ))
                    }
                }
                runOnUiThread {
                    channels = result
                    status.text = "فهرست بروزرسانی شد: ${result.size} کانال"
                    renderChannels()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "اتصال به منبع ناموفق بود؛ فهرست قبلی/آزمایشی حفظ شد. نشانی منبع یا اینترنت را بررسی کنید."
                    if (channels.isEmpty()) channels = demoChannels()
                    renderChannels()
                }
            }
        }
    }

    private fun demoChannels() = listOf(
        Channel("نمونه شبکه ۱", "عمومی", "https://example.com", "TV"),
        Channel("نمونه شبکه ۲", "زنده", "https://example.org", "HD"),
        Channel("نمونه شبکه ۳", "سایر", "https://www.iana.org/domains/reserved", "★")
    )

    private fun addChannelDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(30,10,30,0) }
        val name = EditText(this).apply { hint = "نام شبکه" }
        val url = EditText(this).apply { hint = "لینک HTTPS شبکه" }
        box.addView(name); box.addView(url)
        AlertDialog.Builder(this).setTitle("افزودن شبکه").setView(box)
            .setNegativeButton("انصراف", null)
            .setPositiveButton("ذخیره") { _, _ ->
                val u = url.text.toString().trim()
                if (!u.startsWith("https://")) toast("لینک باید با https:// شروع شود.")
                else {
                    val current = channels.toMutableList()
                    current.add(Channel(name.text.toString().ifBlank { "شبکه جدید" }, "عمومی", u, "TV"))
                    channels = current
                    saveChannels()
                    renderChannels()
                }
            }.show()
    }

    private fun sourceDialog() {
        val input = EditText(this).apply {
            hint = "https://your-domain.example/channels.json"
            setText(prefs.getString("feed_url", ""))
        }
        AlertDialog.Builder(this).setTitle("نشانی فهرست JSON")
            .setMessage("یک منبع HTTPS که JSON کانال‌ها را برمی‌گرداند وارد کنید. برنامه سرور عمومی تصادفی یا پراکسی ناشناس انتخاب نمی‌کند.")
            .setView(input)
            .setNegativeButton("انصراف", null)
            .setPositiveButton("ذخیره") { _, _ ->
                val value = input.text.toString().trim()
                if (value.isNotBlank() && !value.startsWith("https://")) toast("نشانی باید HTTPS باشد.")
                else {
                    prefs.edit().putString("feed_url", value).apply()
                    refreshChannels()
                }
            }.show()
    }

    private fun saveChannels() {
        val arr = JSONArray()
        channels.forEach { c ->
            arr.put(JSONObject().put("name", c.name).put("category", c.category).put("url", c.url).put("logo", c.logo))
        }
        prefs.edit().putString("channels_json", arr.toString()).apply()
    }

    private fun openChannel(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { toast("باز کردن لینک ممکن نشد.") }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
