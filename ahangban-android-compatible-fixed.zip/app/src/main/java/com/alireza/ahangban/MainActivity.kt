package com.alireza.ahangban

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import android.graphics.Color
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private var player: MediaPlayer? = null
    private var dark = false
    private var page = 0
    private var smsMode = false
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private val tones = (1..10).map { "tone%02d.wav".format(it) }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showHome() }
    @Suppress("DEPRECATION")
    private fun isEnglish(): Boolean {
        val language = if (Build.VERSION.SDK_INT >= 24) {
            resources.configuration.locales[0].language
        } else {
            resources.configuration.locale.language
        }
        return language == "en"
    }
    private fun tr(fa: String, en: String) = if (isEnglish()) en else fa

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(18, 22, 18, 18)
            setBackgroundColor(if (dark) Color.rgb(24,19,36) else Color.rgb(247,244,252))
        }
        root.addView(TextView(this).apply {
            text = "♫  " + tr("آهنگ‌بان", "AhangBan"); textSize = 26f; gravity = Gravity.CENTER
            setTextColor(if (dark) Color.WHITE else Color.rgb(49,30,78)); setPadding(0,8,0,18)
        })
        val tabs = LinearLayout(this)
        tabs.addView(button(tr("آهنگ زنگ", "Ringtone")) { smsMode=false; page=0; renderList() }, LinearLayout.LayoutParams(0,-2,1f))
        tabs.addView(button(tr("آهنگ پیامک", "SMS sound")) { smsMode=true; page=0; renderList() }, LinearLayout.LayoutParams(0,-2,1f))
        root.addView(tabs)
        root.addView(button(tr("تنظیمات ⚙", "Settings ⚙")) { showSettings() })
        status = TextView(this).apply {
            text = tr("برای اعمال صدا، اجازه تغییر تنظیمات سیستم لازم است.", "Allow modify-system-settings permission to apply a sound.")
            textSize=12f; setTextColor(if (dark) Color.LTGRAY else Color.DKGRAY); setPadding(4,12,4,12)
        }
        root.addView(status)
        list = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        root.addView(list)
        setContentView(root); renderList()
    }

    private fun renderList() {
        list.removeAllViews()
        list.addView(TextView(this).apply {
            text = if (smsMode) tr("صداهای پیامک (حداکثر ۲ ثانیه)", "SMS tones (max 2 seconds)") else tr("آهنگ‌های زنگ", "Ringtones")
            textSize=18f; setTextColor(if (dark) Color.WHITE else Color.BLACK); setPadding(4,16,4,10)
        })
        tones.forEachIndexed { index, name ->
            val row = LinearLayout(this).apply {
                orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(8,8,8,8)
                setBackgroundColor(if (dark) Color.rgb(45,36,61) else Color.WHITE)
            }
            row.addView(TextView(this).apply {
                text=tr("آهنگ ${index+1}", "Tone ${index+1}"); textSize=15f
                setTextColor(if (dark) Color.WHITE else Color.DKGRAY)
            }, LinearLayout.LayoutParams(0,-2,1f))
            row.addView(button(tr("پخش", "Play")) { playTone(name) })
            row.addView(button(tr("اعمال", "Apply")) { applyTone(name, smsMode) })
            val lp=LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=7; list.addView(row,lp)
        }
        list.addView(TextView(this).apply {
            text=tr("۱۰ صدای نمونه اصلی داخل برنامه قرار دارد. نسخه بعدی می‌تواند به کاتالوگ‌های آنلاین دارای مجوز متصل شود.",
                "10 original sample tones are included. Future versions can connect to licensed online catalogs.")
            textSize=12f; setTextColor(if (dark) Color.LTGRAY else Color.DKGRAY); setPadding(4,12,4,4)
        })
    }

    private fun button(label: String, action: () -> Unit) =
        Button(this).apply { text=label; textSize=12f; setOnClickListener { action() } }

    private fun playTone(name: String) {
        try {
            player?.release()
            val afd=assets.openFd("tones/$name")
            player=MediaPlayer().apply {
                setDataSource(afd.fileDescriptor,afd.startOffset,afd.length)
                setOnCompletionListener { it.release(); player=null }; prepare(); start()
            }
            afd.close()
        } catch (_: Exception) { status.text=tr("پخش صدا ناموفق بود.", "Could not play sound.") }
    }

    private fun applyTone(name: String, notification: Boolean) {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.System.canWrite(this)) {
            status.text=tr("ابتدا اجازه تغییر تنظیمات سیستم را فعال کنید.", "Please grant modify system settings permission.")
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
            return
        }
        try {
            val temp=File(cacheDir,name)
            assets.open("tones/$name").use { input -> FileOutputStream(temp).use { input.copyTo(it) } }
            val values=ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, if(notification) "AhangBan_SMS_$name" else "AhangBan_Ringtone_$name")
                put(MediaStore.MediaColumns.MIME_TYPE,"audio/wav")
                put(MediaStore.Audio.Media.IS_RINGTONE,!notification)
                put(MediaStore.Audio.Media.IS_NOTIFICATION,notification)
                put(MediaStore.Audio.Media.IS_ALARM,false); put(MediaStore.Audio.Media.IS_MUSIC,false)
            }
            val uri=contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,values)
                ?: throw IllegalStateException("Cannot add audio")
            contentResolver.openOutputStream(uri)?.use { out -> temp.inputStream().use { it.copyTo(out) } }
            RingtoneManager.setActualDefaultRingtoneUri(this,
                if(notification) RingtoneManager.TYPE_NOTIFICATION else RingtoneManager.TYPE_RINGTONE,uri)
            status.text=if(notification)
                tr("صدای اعلان پیش‌فرض گوشی تغییر کرد. اگر برنامه پیامک صدای اختصاصی دارد، آن را در تنظیمات همان برنامه هم انتخاب کنید.",
                   "The phone's default notification sound changed. If your SMS app has its own sound setting, select it there too.")
            else tr("آهنگ زنگ گوشی با موفقیت تغییر کرد.", "Phone ringtone changed successfully.")
        } catch(e:Exception) { status.text=tr("اعمال صدا انجام نشد: ","Could not apply sound: ")+(e.message ?: "") }
    }

    private fun showSettings() {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,24,24,24)
            setBackgroundColor(if(dark) Color.rgb(24,19,36) else Color.rgb(247,244,252)) }
        box.addView(TextView(this).apply { text=tr("تنظیمات","Settings"); textSize=24f; setTextColor(if(dark) Color.WHITE else Color.BLACK) })
        box.addView(button(tr("تغییر حالت شب / روز","Toggle dark / light mode")) { dark=!dark; showHome() })
        box.addView(TextView(this).apply {
            text="\n"+tr("زبان برنامه از زبان گوشی پیروی می‌کند (فارسی / English)\n\nسازنده: alireza10721@gmail.com",
                "App language follows device language (Persian / English)\n\nDeveloper: alireza10721@gmail.com")
            textSize=15f; setTextColor(if(dark) Color.WHITE else Color.DKGRAY)
        })
        box.addView(button(tr("بازگشت","Back")) { showHome() }); setContentView(box)
    }
    override fun onDestroy() { player?.release(); player=null; super.onDestroy() }
}
